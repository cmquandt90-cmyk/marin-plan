// src/lib/calc.ts

export type Inputs = {
  // Assumptions + 2025 Income
  totalSale: number;            // C3
  capGainRateSale: number;      // C4  (fraction)
  ordinaryIncomeRate: number;   // C6
  income2025: number;           // C8

  // Tax Benefits
  dafContribution2025: number;  // C14
  oilGas2025: number;           // C15

  // Allocations (fractions)
  publicEquityAlloc: number;
  privateEquityAlloc: number;
  privateCreditAlloc: number;
  muniAlloc: number;
  quantinnoAlloc: number;
  realEstateAlloc: number;
  metalsAlloc: number;
  startupsAlloc: number;
  cryptoAlloc: number;

  // ROI (fractions/year)
  publicEquityGrowth: number;
  privateEquityGrowth: number;
  privateCreditCoupon: number;
  muniCoupon: number;
  quantinnoGrowth: number;
  realEstateGrowth: number;
  metalsGrowth: number;
  startupsGrowth: number;
  cryptoGrowth: number;

  // aliases expected by Results
  daf: number;     // = dafContribution2025
  oilGas: number;  // = oilGas2025
};

const MAX = (a: number, b: number) => (a > b ? a : b);
const MIN = (a: number, b: number) => (a < b ? a : b);
const r0 = (n: number) => Math.round(n || 0);

function splitSavingsByStrategy(
  income: number,
  capGainRate: number,
  ordinaryRate: number,
  daf: number,
  oilGasDeductible: number
) {
  const dafToOrd = MIN(daf, income);
  const dafToCG  = MAX(0, daf - income);
  const dafSaved = dafToOrd * ordinaryRate + dafToCG * capGainRate;

  const remainingOrd = MAX(0, income - daf);
  const ogToOrd = MIN(oilGasDeductible, remainingOrd);
  const ogToCG  = MAX(0, oilGasDeductible - remainingOrd);
  const ogSaved = ogToOrd * ordinaryRate + ogToCG * capGainRate;

  return { dafSaved, ogSaved };
}

export function computeAll(form: Inputs) {
  const C3  = form.totalSale;
  const C4  = form.capGainRateSale;
  const C6  = form.ordinaryIncomeRate;
  const C8  = form.income2025;
  const C14 = form.daf;
  const C15 = form.oilGas;

  // 85% first-year deduction on O&G
  const oilDeductible = C15 * 0.85;

  // Carry forward (implicit, not used elsewhere)
  const C16 = MAX(0, (C14 + oilDeductible) - C8);

  // Baseline pre-deduction tax: (C3*C4) + (C8*C6)
  const TAX_BASELINE = C3 * C4 + C8 * C6;

  // After planning tax (C22)
  const deductibleTotal = C14 + oilDeductible;
  const TAX_AFTER =
    MAX(0, C8 - MIN(C8, deductibleTotal)) * C6 +
    MAX(0, C3 - MAX(0, deductibleTotal - C8)) * C4;

  const TAX_SAVED = TAX_BASELINE - TAX_AFTER;

  // Net after-tax proceeds: (C3 + C8) - (C14 + C15) - TAX_AFTER
  const NET_PROCEEDS = (C3 + C8) - (C14 + C15) - TAX_AFTER;

  const TOTAL_INCL_CHARITABLE = NET_PROCEEDS + C14 + C15;
  const TOTAL_EXCL_CHARITABLE = NET_PROCEEDS + C15;

  const { dafSaved: DAF_SAVED, ogSaved: OIL_SAVED } =
    splitSavingsByStrategy(C8, C4, C6, C14, oilDeductible);

  // ---- Asset mix (Year 0 buckets = NET_PROCEEDS × allocation) ----
  const base = NET_PROCEEDS;
  const alloc = {
    public:  form.publicEquityAlloc || 0,
    privEq:  form.privateEquityAlloc || 0,
    privCr:  form.privateCreditAlloc || 0,
    muni:    form.muniAlloc || 0,
    quant:   form.quantinnoAlloc || 0,
    real:    form.realEstateAlloc || 0,
    metal:   form.metalsAlloc || 0,
    start:   form.startupsAlloc || 0,
    crypto:  form.cryptoAlloc || 0,
  };

  const y0 = {
    public: base * alloc.public,
    privEq: base * alloc.privEq,
    privCr: base * alloc.privCr,
    muni:   base * alloc.muni,
    quant:  base * alloc.quant,
    real:   base * alloc.real,
    metal:  base * alloc.metal,
    start:  base * alloc.start,
    crypto: base * alloc.crypto,
  };

  // ---- Growth projection (iterative, Excel-style rounding) ----
  // Always reinvest Private Credit and Muni coupons
  const rate = {
    public: form.publicEquityGrowth || 0,
    privEq:  form.privateEquityGrowth || 0,
    privCr:  form.privateCreditCoupon || 0,
    muni:    form.muniCoupon || 0,
    quant:   form.quantinnoGrowth || 0,
    real:    form.realEstateGrowth || 0,
    metal:   form.metalsGrowth || 0,
    start:   form.startupsGrowth || 0,
    crypto:  form.cryptoGrowth || 0,
  };

  let cur = { ...y0 };
  const round2 = (x: number) => Math.round((x || 0) * 100) / 100;
  const total  = (v: typeof cur) =>
    v.public + v.privEq + v.privCr + v.muni + v.quant + v.real + v.metal + v.start + v.crypto;

  const growthData = [{ year: 0, value: total(cur) }];

  for (let t = 1; t <= 30; t++) {
    cur.public = round2(cur.public * (1 + rate.public));
    cur.privEq = round2(cur.privEq * (1 + rate.privEq));
    cur.privCr = round2(cur.privCr * (1 + rate.privCr)); // reinvested
    cur.muni   = round2(cur.muni   * (1 + rate.muni));   // reinvested
    cur.quant  = round2(cur.quant  * (1 + rate.quant));
    cur.real   = round2(cur.real   * (1 + rate.real));
    cur.metal  = round2(cur.metal  * (1 + rate.metal));
    cur.start  = round2(cur.start  * (1 + rate.start));
    cur.crypto = round2(cur.crypto * (1 + rate.crypto));
    growthData.push({ year: t, value: total(cur) });
  }

  // Tax Impact series for the bar chart
  const taxImpactData = [
    { label: "Baseline", value: TAX_BASELINE },
    { label: "After Planning", value: TAX_AFTER },
  ];

  const NET_BEFORE_PLANNING = (C3 + C8) - TAX_BASELINE;

  return {
    // KPIs
    TAX_BASELINE: r0(TAX_BASELINE),
    TAX_AFTER:    r0(TAX_AFTER),
    TAX_SAVED:    r0(TAX_SAVED),
    NET_PROCEEDS: r0(NET_PROCEEDS),
    TOTAL_INCL_CHARITABLE: r0(TOTAL_INCL_CHARITABLE),
    TOTAL_EXCL_CHARITABLE: r0(TOTAL_EXCL_CHARITABLE),

    // Strategy breakdown
    DAF_DEDUCTION: r0(C14),
    OIL_DEDUCTION: r0(oilDeductible),
    DAF_SAVED:     r0(DAF_SAVED),
    OIL_SAVED:     r0(OIL_SAVED),
    CARRY_FORWARD: r0(C16),

    // Charts
    assetMixData: [
      { name: "Public Equities", value: y0.public },
      { name: "Private Equity", value: y0.privEq },
      { name: "Private Credit", value: y0.privCr },
      { name: "Municipal Bonds", value: y0.muni },
      { name: "Quantinno", value: y0.quant },
      { name: "Real Estate", value: y0.real },
      { name: "Precious Metals", value: y0.metal },
      { name: "Startups/Angel", value: y0.start },
      { name: "Crypto", value: y0.crypto },
      { name: "Donor Advised Fund", value: C14 },
      { name: "Oil & Gas", value: C15 },
    ],
    growthData,
    taxImpactData,

    // extras
    PRE_TAX_LIABILITY: r0(TAX_BASELINE),
    NET_BEFORE_PLANNING: r0(NET_BEFORE_PLANNING),
  };
}
