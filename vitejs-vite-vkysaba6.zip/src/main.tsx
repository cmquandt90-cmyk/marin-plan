import './index.css';
import React from 'react'
import ReactDOM from 'react-dom/client'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import App from './App'
import AssumptionsPage from './pages/AssumptionsPage'
import ResultsPage from './pages/ResultsPage'

const router = createBrowserRouter([
  {
    path: '/',
    element: <AssumptionsPage />,
  },
  {
    path: '/results',
    element: <ResultsPage />,
  },
  {
    path: '/app',
    element: <App />,
  },
])

ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>,
)
