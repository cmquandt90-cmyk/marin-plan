import React, { useRef } from "react";
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  BarChart,
  Bar,
  LabelList,
} from "recharts";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";

/* ---------------------- Helpers ---------------------- */
const money = (n: number) =>
  "$" + Math.round(n).toLocaleString(undefined, { maximumFractionDigits: 0 });

const moneyShort = (n: number) => {
  if (n >= 1_000_000_000) return `$${(n / 1_000_000_000).toFixed(1)}B`;
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `$${(n / 1_000).toFixed(1)}K`;
  return `$${Math.round(n).toLocaleString()}`;
};

const toBillions = (n: number) => `$${(n / 1_000_000_000).toFixed(1)}B`;

/* ---------------------- Brand Colors ---------------------- */
const TH_BLUE = "#0f2742";
const TH_BLUE_ALT = "#1b3b61";
const TH_GOLD = "rgb(193,137,23)";

/* ---------------------- Key Numbers ---------------------- */
const BUSINESS_SALE = 65_000_000;
const INCOME_2025 = 12_000_000;

const NET_PROCEEDS = 48_074_800;
const TOTAL_INCL_CHARITABLE = 55_574_800;
const TAX_BASELINE = 24_571_000; // baseline (pre-planning)
const TAX_AFTER = 21_425_200; // after planning (post)
const TAX_SAVED = 3_145_800;
const DAF = 6_500_000;
const OIL_GAS = 1_000_000;

// §453 transparency row (just crossed out)
const DEFERRAL_453 = {
  allocation: 20_000_000,
  deduction: 20_000_000,
  taxSavings: 5_980_000,
};

/* ---------------------- Asset Mix ---------------------- */
const allocPct: Record<string, number> = {
  "Public Equities": 16.67,
  "Private Equity": 22.22,
  "Private Credit": 11.11,
  "Municipal Bonds": 11.11,
  Quantinno: 11.11,
  "Real Estate": 22.22,
  "Precious Metals": 5.55,
  "Startups/Angel": 5.55,
  Crypto: 5.56,
};

const portfolioSlices = Object.entries(allocPct).map(([name, pct]) => ({
  name,
  value: (pct / 100) * NET_PROCEEDS,
}));

const assetMixData = [
  ...portfolioSlices,
  { name: "Donor Advised Fund", value: DAF },
  { name: "Oil & Gas", value: OIL_GAS },
];

const COLORS = [
  "#0f2742",
  "#1b3b61",
  "#274a77",
  "#3b6aa5",
  "#7ea6d8",
  "#c88a11",
  "#e2b24a",
  "#f0c871",
  "#f5dab0",
  "#d97706", // DAF
  "#2563eb", // O&G
];

/* ---------------------- Growth ---------------------- */
const growthData = [
  { year: 6, value: 87_110_765 },
  { year: 12, value: 163_134_324 },
  { year: 18, value: 318_805_995 },
  { year: 24, value: 656_911_793 },
  { year: 30, value: 1_439_267_128 },
];

/* ---------------------- Tax Impact ---------------------- */
const taxImpactData = [
  { label: "Baseline", value: TAX_BASELINE }, // red
  { label: "After Planning", value: TAX_AFTER }, // blue
];

/* ---------------------- Small Components ---------------------- */
function KPI({
  label,
  value,
  tone,
  sub,
  valueColor, // overrides tone when provided
}: {
  label: string;
  value: number;
  tone?: "emerald" | "indigo" | "amber";
  sub?: string;
  valueColor?: string;
}) {
  const toneMap: Record<string, string> = {
    emerald: "text-emerald-600",
    indigo: "text-indigo-700",
    amber: "text-amber-600",
  };
  const toneClass = tone ? toneMap[tone] : "text-gray-900";
  return (
    <div className="bg-white rounded-2xl shadow p-6 text-center border">
      <p className="text-xs uppercase tracking-wide text-gray-500">{label}</p>
      <p
        className={`text-3xl font-extrabold mt-1 ${valueColor ? "" : toneClass}`}
        style={valueColor ? { color: valueColor } : undefined}
      >
        {money(value)}
      </p>
      {sub ? <p className="text-[11px] text-gray-500 mt-1">{sub}</p> : null}
    </div>
  );
}

/** Clean, PDF-safe strikethrough (consistent with html2canvas) */
function Strike({ children }: { children: React.ReactNode }) {
  return (
    <span className="relative inline-block text-gray-500">
      <span className="opacity-80">{children}</span>
      <span
        className="absolute left-0 right-0 border-t border-gray-400"
        style={{ top: "50%", transform: "translateY(-50%)" }}
      />
    </span>
  );
}

function SwatchLegend({
  data,
  colors,
}: {
  data: { name: string; value: number }[];
  colors: string[];
}) {
  const total = data.reduce((s, x) => s + x.value, 0);
  return (
    <ul className="space-y-2">
      {data.map((d, i) => {
        const pct = total ? (d.value / total) * 100 : 0;
        return (
          <li key={d.name} className="flex items-center gap-3 text-sm text-gray-800">
            <span
              className="inline-block h-3 w-3 rounded-sm"
              style={{ background: colors[i % colors.length] }}
            />
            <span className="whitespace-nowrap">
              {d.name} — {moneyShort(d.value)} ({pct.toFixed(1)}%)
            </span>
          </li>
        );
      })}
    </ul>
  );
}

/* ---------------------- Page ---------------------- */
export default function App() {
  const pdfRef = useRef<HTMLDivElement>(null);

  // Export a pixel-perfect screenshot of the page content (no extra PDF header)
  const handleDownloadPDF = async () => {
    if (!pdfRef.current) return;

    const canvas = await html2canvas(pdfRef.current, {
      scale: 2,
      backgroundColor: "#ffffff",
      useCORS: true,
      logging: false,
      windowWidth: document.documentElement.scrollWidth,
    });
    const imgData = canvas.toDataURL("image/png");

    const pdf = new jsPDF({ unit: "pt", format: "letter", orientation: "portrait" });
    const pageWidth = pdf.internal.pageSize.getWidth(); // 612
    const pageHeight = pdf.internal.pageSize.getHeight(); // 792

    // Edge-to-edge to mirror the site layout
    const left = 0;
    const topStart = 0;
    const imgWidth = pageWidth;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;

    if (imgHeight <= pageHeight) {
      pdf.addImage(imgData, "PNG", left, topStart, imgWidth, imgHeight);
    } else {
      // paginate tall content
      let remaining = imgHeight;
      let position = topStart;
      while (remaining > 0) {
        pdf.addImage(imgData, "PNG", left, position, imgWidth, imgHeight);
        remaining -= pageHeight;
        position -= pageHeight; // move image up for next slice
        if (remaining > 0) pdf.addPage();
      }
    }

    pdf.save("True-Harvest—Marvin-Post-Sale-Plan.pdf");
  };

  return (
    <div className="min-h-screen bg-gray-100 text-gray-900">
      {/* Header (onscreen) */}
      <header className="flex items-center justify-between px-8 py-6 bg-white border-b sticky top-0 z-10">
        <div className="flex items-center gap-4">
          <img src="/LOGO.png" alt="True Harvest" className="h-14 w-auto" />
          <div>
            <h1 className="text-3xl font-extrabold" style={{ color: TH_BLUE }}>
              Marvin Family — Post-Sale Investment Strategy
            </h1>
            <p className="text-sm text-gray-600">2025 Projection</p>
          </div>
        </div>

        <button
          onClick={handleDownloadPDF}
          className="rounded-xl bg-[rgb(193,137,23)] text-white font-semibold px-4 py-2 shadow hover:opacity-95 active:scale-[0.99] transition"
        >
          Download PDF
        </button>
      </header>

      {/* Main content to capture as PDF */}
      <main ref={pdfRef} className="max-w-7xl mx-auto p-8 space-y-10">
        {/* === KPIs ROW 1 (Baseline numbers) === */}
        <section className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <KPI
            label="Business Sale Proceeds"
            value={BUSINESS_SALE}
            sub="Gross sale amount"
            valueColor={TH_BLUE}
          />
          <KPI
            label="2025 Income"
            value={INCOME_2025}
            sub="Projected ordinary income"
            valueColor={TH_BLUE}
          />
        </section>

        {/* === KPIs ROW 2 (Outcome metrics) === */}
        <section className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <KPI
            label="Taxes Saved"
            value={TAX_SAVED}
            tone="emerald"
            sub="From DAF + Oil & Gas deductions"
          />
          <KPI
            label="Net After-Tax Proceeds"
            value={NET_PROCEEDS}
            tone="indigo"
            sub="After implementing planning"
          />
          <KPI
            label="Total Including Charitable"
            value={TOTAL_INCL_CHARITABLE}
            sub="Net proceeds + DAF"
            valueColor={TH_GOLD}
          />
        </section>

        {/* === Charts Row === */}
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Asset Mix */}
          <div className="bg-white rounded-2xl shadow p-6">
            <h2 className="text-lg font-semibold mb-4">
              Asset Mix (incl. DAF &amp; Oil&nbsp;&amp;&nbsp;Gas)
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-[1.2fr_1fr] lg:grid-cols-[1.4fr_1fr] gap-6 items-center">
              <div className="h-[320px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart margin={{ top: 8, right: 8, bottom: 8, left: 8 }}>
                    <Pie
                      data={assetMixData}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      innerRadius={70}
                      outerRadius={120}
                      paddingAngle={2}
                      label={false}
                    >
                      {assetMixData.map((_, i) => (
                        <Cell key={i} fill={COLORS[i % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(v: number, n: string) => [money(v), n]} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div>
                <SwatchLegend data={assetMixData} colors={COLORS} />
                <div className="text-xs text-gray-500 mt-3 rounded-lg bg-gray-50 p-3">
                  Portfolio base: {money(NET_PROCEEDS)} • DAF {money(DAF)} • Oil &amp; Gas{" "}
                  {money(OIL_GAS)}
                </div>
              </div>
            </div>
          </div>

          {/* Growth (billions, no clipping) */}
          <div className="bg-white rounded-2xl shadow p-6">
            <h2 className="text-lg font-semibold mb-4">Growth Projection</h2>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={growthData} margin={{ top: 10, right: 24, left: 72, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="year" tickFormatter={(y) => `${y}y`} />
                <YAxis width={64} domain={[0, "dataMax"]} tickFormatter={toBillions} />
                <Tooltip formatter={(v: number) => money(v)} labelFormatter={(l) => `Year ${l}`} />
                <Line
                  type="monotone"
                  dataKey="value"
                  stroke={TH_BLUE}
                  strokeWidth={3}
                  dot={{ r: 4, stroke: TH_BLUE, strokeWidth: 2, fill: "#fff" }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </section>

        {/* === Tax impact (Baseline red, After Planning blue) === */}
        <section className="bg-white rounded-2xl shadow p-6">
          <h2 className="text-lg font-semibold mb-4">Tax Impact — Baseline vs After Planning</h2>
          <div className="grid grid-cols-1 md:grid-cols-[2fr_1fr] gap-8">
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  layout="vertical"
                  data={taxImpactData}
                  margin={{ left: 140, right: 120, top: 8, bottom: 8 }}
                >
                  {/* Removed CartesianGrid to drop grey dashed lines */}
                  <XAxis type="number" hide />
                  <YAxis type="category" dataKey="label" width={120} />
                  <Tooltip formatter={(v: number) => money(v)} />
                  <Bar dataKey="value" radius={[6, 6, 6, 6]}>
                    {taxImpactData.map((_, i) => (
                      <Cell key={i} fill={i === 0 ? "#b91c1c" : TH_BLUE_ALT} />
                    ))}
                    {/* Bold WHITE right-side labels */}
                    <LabelList
                      dataKey="value"
                      position="right"
                      offset={16}
                      content={(props: any) => {
                        const { x, y, value, height } = props;
                        const cy = (y ?? 0) + (height ?? 0) / 2 + 4; // vertical center
                        const cx = (x ?? 0) + 16;
                        return (
                          <text x={cx} y={cy} fontSize={12} fontWeight={700} fill="#ffffff">
                            {money(value as number)}
                          </text>
                        );
                      }}
                    />
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            {/* Center the callout vertically & horizontally; match chart height */}
            <div className="rounded-xl border bg-gray-50 p-6 text-center h-56 flex flex-col items-center justify-center">
              <p className="text-sm text-gray-600">Taxes Saved</p>
              <p className="text-3xl font-extrabold text-emerald-600">{money(TAX_SAVED)}</p>
              <p className="text-xs text-gray-500 mt-1">
                {money(TAX_BASELINE)} baseline vs {money(TAX_AFTER)} after planning.
              </p>
            </div>
          </div>
        </section>

        {/* === Strategies (453 crossed out only) === */}
        <section className="bg-white rounded-2xl shadow p-6">
          <h2 className="text-lg font-semibold mb-4">Tax Strategies</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-100">
                <tr>
                  <th className="p-3 text-left">Strategy</th>
                  <th className="p-3 text-right">Allocation</th>
                  <th className="p-3 text-right">Deduction</th>
                  <th className="p-3 text-right">Tax Savings</th>
                </tr>
              </thead>
              <tbody>
                {[
                  { strategy: "Donor Advised Fund", allocation: DAF, deduction: DAF, savings: 2_782_000 },
                  { strategy: "Oil & Gas", allocation: OIL_GAS, deduction: 850_000, savings: 363_800 },
                ].map((r) => (
                  <tr key={r.strategy} className="border-t">
                    <td className="p-3">{r.strategy}</td>
                    <td className="p-3 text-right">{money(r.allocation)}</td>
                    <td className="p-3 text-right">{money(r.deduction)}</td>
                    <td className="p-3 text-right font-semibold text-emerald-700">
                      {money(r.savings)}
                    </td>
                  </tr>
                ))}
                {/* §453 crossed out with PDF-safe custom strike */}
                <tr className="border-t bg-gray-50">
                  <td className="p-3 text-gray-500">
                    <Strike>§453 Deferral</Strike>
                  </td>
                  <td className="p-3 text-right text-gray-500">
                    <Strike>{money(DEFERRAL_453.allocation)}</Strike>
                  </td>
                  <td className="p-3 text-right text-gray-500">
                    <Strike>{money(DEFERRAL_453.deduction)}</Strike>
                  </td>
                  <td className="p-3 text-right text-gray-500">
                    <Strike>{money(DEFERRAL_453.taxSavings)}</Strike>
                  </td>
                </tr>
                <tr className="border-t">
                  <td className="p-3 font-semibold">Total (elected strategies)</td>
                  <td className="p-3 text-right font-semibold">{money(DAF + OIL_GAS)}</td>
                  <td className="p-3 text-right font-semibold">{money(DAF + 850_000)}</td>
                  <td className="p-3 text-right font-bold text-amber-600">{money(TAX_SAVED)}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>

        <footer className="text-xs text-gray-500 pt-4 text-center">
          © 2025 True Harvest Wealth Management — Confidential
        </footer>
      </main>
    </div>
  );
}
