// src/pages/ResultsPage.tsx
import React from "react";
import { useLocation, Link } from "react-router-dom";
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  LineChart,
  Line,
  XAxis,
  YAxis,
  BarChart,
  Bar,
  LabelList,
} from "recharts";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { computeAll } from "../lib/calc";

/* ---------------------- Helpers ---------------------- */
const TH_BLUE = "#0f2742";
const TH_GOLD = "rgb(193,137,23)";

const money = (n: number) =>
  "$" + Math.round(n || 0).toLocaleString(undefined, { maximumFractionDigits: 0 });

const toBillions = (n: number) => `$${((n || 0) / 1_000_000_000).toFixed(1)}B`;

function KPI({
  label,
  value,
  sub,
  color,
}: {
  label: string;
  value: number;
  sub?: string;
  color?: string;
}) {
  return (
    <div className="bg-white rounded-2xl shadow p-6 text-center">
      <p className="text-xs uppercase tracking-wide text-gray-500">{label}</p>
      <p className="text-3xl font-extrabold mt-1" style={color ? { color } : undefined}>
        {money(value)}
      </p>
      {sub ? <p className="text-[11px] text-gray-500 mt-1">{sub}</p> : null}
    </div>
  );
}

function SwatchLegend({
  data,
  colors,
}: {
  data: { name: string; value: number }[];
  colors: string[];
}) {
  const total = data.reduce((s, x) => s + (x.value || 0), 0);
  return (
    <ul className="space-y-2">
      {data.map((d, i) => {
        const pct = total ? (d.value / total) * 100 : 0;
        return (
          <li key={d.name} className="flex items-center gap-3 text-sm text-gray-800">
            <span
              className="inline-block h-3 w-3 rounded-sm"
              style={{ background: colors[i % colors.length] }}
            />
            <span className="whitespace-nowrap">
              {d.name} — {money(d.value)} ({pct.toFixed(1)}%)
            </span>
          </li>
        );
      })}
    </ul>
  );
}

/* ---------------------- Page ---------------------- */
export default function ResultsPage() {
  const location = useLocation();
  const form = (location.state as any)?.form;

  if (!form) {
    return (
      <div className="p-8">
        <p className="mb-4 text-red-600">
          ⚠️ No assumptions provided. Go back and enter values.
        </p>
        <Link to="/" className="text-indigo-600 underline">
          Back to Assumptions
        </Link>
      </div>
    );
  }

  const {
    TAX_BASELINE,
    TAX_AFTER,
    TAX_SAVED,
    NET_PROCEEDS,
    TOTAL_INCL_CHARITABLE,
    assetMixData,
    growthData,
    taxImpactData,
    DAF_DEDUCTION,
    OIL_DEDUCTION,
    DAF_SAVED,
    OIL_SAVED,
  } = computeAll(form);

  const COLORS = [
    "#0f2742", "#1b3b61", "#274a77", "#3b6aa5", "#7ea6d8",
    "#c88a11", "#e2b24a", "#f0c871", "#f5dab0",
    "#d97706", // DAF
    "#2563eb", // O&G
  ];

  /* ---------------------- PDF Export ---------------------- */
  const handleDownloadPDF = async () => {
    const node = document.getElementById("report-content");
    if (!node) return;

    const headerNode = document.getElementById("pdf-header");
    if (!headerNode) return;

    const headerCanvas = await html2canvas(headerNode as HTMLElement, {
      scale: 2,
      backgroundColor: "#ffffff",
    });
    const headerImg = headerCanvas.toDataURL("image/png");

    const contentCanvas = await html2canvas(node, { scale: 2, backgroundColor: "#ffffff" });
    const contentImg = contentCanvas.toDataURL("image/png");

    const pdf = new jsPDF("p", "mm", "a4");
    const pdfWidth = pdf.internal.pageSize.getWidth();

    const headProps = (pdf as any).getImageProperties(headerImg);
    const headH = (headProps.height * pdfWidth) / headProps.width;
    pdf.addImage(headerImg, "PNG", 0, 0, pdfWidth, headH);

    const contProps = (pdf as any).getImageProperties(contentImg);
    const contH = (contProps.height * pdfWidth) / contProps.width;
    pdf.addImage(contentImg, "PNG", 0, headH, pdfWidth, contH);

    pdf.save("Marvin-Family-Report.pdf");
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      {/* Visible header */}
      <header className="flex items-center justify-between px-8 py-6 bg-white border-b">
        <div className="flex items-center gap-4">
          <img src="/LOGO.png" alt="True Harvest" className="h-14 w-auto" />
          <div>
            <h1 className="text-3xl font-extrabold" style={{ color: TH_BLUE }}>
              Marvin Family — Post-Sale Investment Strategy
            </h1>
            <p className="text-sm text-gray-600">2025 Projection</p>
          </div>
        </div>
        <button
          onClick={handleDownloadPDF}
          className="bg-[rgb(193,137,23)] hover:opacity-95 text-white px-4 py-2 rounded shadow"
        >
          Download PDF
        </button>
      </header>

      {/* Off-screen header for PDF capture */}
      <div
        id="pdf-header"
        className="px-8 py-6 bg-white"
        style={{ position: "absolute", left: -10000, top: -10000, width: "1024px" }}
      >
        <div className="flex items-center gap-4">
          <img src="/LOGO.png" alt="True Harvest" className="h-14 w-auto" />
          <div>
            <h1 className="text-3xl font-extrabold" style={{ color: TH_BLUE }}>
              Marvin Family — Post-Sale Investment Strategy
            </h1>
            <p className="text-sm text-gray-600">2025 Projection</p>
          </div>
        </div>
      </div>

      <main id="report-content" className="max-w-7xl mx-auto p-8 space-y-10">
        {/* Top KPIs row 1 */}
        <section className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <KPI
            label="Business Sale Proceeds"
            value={form.totalSale}
            sub="Gross sale amount"
            color={TH_BLUE}
          />
          <KPI
            label="2025 Income"
            value={form.income2025}
            sub="Projected ordinary income"
            color={TH_BLUE}
          />
        </section>

        {/* Top KPIs row 2 */}
        <section className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <KPI
            label="Taxes Saved"
            value={TAX_SAVED}
            sub="From DAF + Oil & Gas deductions"
            color="#059669"
          />
          <KPI
            label="Net After-Tax Proceeds"
            value={NET_PROCEEDS}
            sub="After implementing planning"
            color="#1b3b61"
          />
          {/* << label tweak here */}
          <KPI
            label="Total Including DAF & Oil & Gas"
            value={TOTAL_INCL_CHARITABLE}
            sub="Net proceeds + DAF + Oil & Gas"
            color={TH_GOLD}
          />
        </section>

        {/* Charts row */}
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Asset Mix */}
          <div className="bg-white rounded-2xl shadow p-6">
            <h2 className="text-lg font-semibold mb-4">
              Asset Mix (incl. DAF &amp; Oil&nbsp;&amp;&nbsp;Gas)
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-[1.4fr_1fr] gap-6 items-center">
              {/* increased height + margins + slightly smaller radius to avoid clipping */}
              <div className="h-[340px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart margin={{ top: 12, right: 24, bottom: 12, left: 24 }}>
                    <Pie
                      data={assetMixData}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      innerRadius={70}
                      outerRadius={115}    // was 120
                      paddingAngle={2}
                      label={false}
                    >
                      {assetMixData.map((_, i) => (
                        <Cell key={i} fill={COLORS[i % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(v: number, n: string) => [money(v), n]} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div>
                <SwatchLegend data={assetMixData} colors={COLORS} />
                <div className="text-xs text-gray-500 mt-3 rounded-lg bg-gray-50 p-3">
                  Portfolio base: {money(NET_PROCEEDS)} • DAF {money(form.daf)} • Oil &amp; Gas{" "}
                  {money(form.oilGas)}
                </div>
              </div>
            </div>
          </div>

          {/* Growth Projection */}
          <div className="bg-white rounded-2xl shadow p-6">
            <h2 className="text-lg font-semibold mb-4">Growth Projection</h2>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={growthData} margin={{ top: 10, right: 24, left: 72, bottom: 20 }}>
                <XAxis dataKey="year" tickFormatter={(y) => `${y}y`} ticks={[0,5,10,15,20,25,30]} />
                <YAxis width={64} domain={[0, "dataMax"]} tickFormatter={toBillions} />
                <Tooltip formatter={(v: number) => money(v)} labelFormatter={(l) => `Year ${l}`} />
                <Line
                  type="monotone"
                  dataKey="value"
                  stroke={TH_BLUE}
                  strokeWidth={3}
                  dot={{ r: 2, stroke: TH_BLUE, strokeWidth: 2, fill: "#fff" }}
                  activeDot={{ r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </section>

        {/* Tax impact (labels centered inside bars) */}
        <section className="bg-white rounded-2xl shadow p-6">
          <h2 className="text-lg font-semibold mb-4">Tax Impact — Baseline vs After Planning</h2>
          <div className="grid grid-cols-1 md:grid-cols-[2fr_1fr] gap-8">
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  layout="vertical"
                  data={taxImpactData}
                  margin={{ left: 140, right: 120, top: 8, bottom: 8 }}
                >
                  <XAxis type="number" hide />
                  <YAxis type="category" dataKey="label" width={120} />
                  <Tooltip formatter={(v: number) => money(v)} />
                  <Bar dataKey="value" radius={[6, 6, 6, 6]}>
                    {taxImpactData.map((_, i) => (
                      <Cell key={i} fill={i === 0 ? "#b91c1c" : "#1b3b61"} />
                    ))}
                    {/* Move numbers from right to centered inside the bars */}
                    <LabelList
                      dataKey="value"
                      position="center"   // change to "insideLeft" if you prefer
                      formatter={(v: number) => money(v)}
                      fill="#ffffff"
                      style={{ fontWeight: 800 }}
                    />
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="rounded-xl border bg-gray-50 p-4 flex flex-col items-center justify-center text-center">
              <p className="text-sm text-gray-600">Taxes Saved</p>
              <p className="text-3xl font-extrabold text-emerald-600">{money(TAX_SAVED)}</p>
              <p className="text-xs text-gray-500 mt-1">
                {money(TAX_BASELINE)} baseline vs {money(TAX_AFTER)} after planning.
              </p>
            </div>
          </div>
        </section>

        {/* Strategies table */}
        <section className="bg-white rounded-2xl shadow p-6">
          <h2 className="text-lg font-semibold mb-4">Tax Strategies</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-100">
                <tr>
                  <th className="p-3 text-left">Strategy</th>
                  <th className="p-3 text-right">Allocation</th>
                  <th className="p-3 text-right">Deduction</th>
                  <th className="p-3 text-right">Tax Savings</th>
                </tr>
              </thead>
              <tbody>
                {[
                  { strategy: "Donor Advised Fund", allocation: form.daf, deduction: DAF_DEDUCTION, savings: DAF_SAVED },
                  { strategy: "Oil & Gas", allocation: form.oilGas, deduction: OIL_DEDUCTION, savings: OIL_SAVED },
                ].map((r) => (
                  <tr key={r.strategy} className="border-t">
                    <td className="p-3">{r.strategy}</td>
                    <td className="p-3 text-right">{money(r.allocation)}</td>
                    <td className="p-3 text-right">{money(r.deduction)}</td>
                    <td className="p-3 text-right font-semibold text-emerald-700">{money(r.savings)}</td>
                  </tr>
                ))}
                {/* §453 crossed out (display only) */}
                <tr className="border-t bg-gray-50">
                  <td className="p-3 text-gray-500 line-through">§453 Deferral</td>
                  <td className="p-3 text-right text-gray-500 line-through">{money(20_000_000)}</td>
                  <td className="p-3 text-right text-gray-500 line-through">{money(20_000_000)}</td>
                  <td className="p-3 text-right text-gray-500 line-through">{money(5_980_000)}</td>
                </tr>
                <tr className="border-t">
                  <td className="p-3 font-semibold">Total (elected strategies)</td>
                  <td className="p-3 text-right font-semibold">{money(form.daf + form.oilGas)}</td>
                  <td className="p-3 text-right font-semibold">{money(DAF_DEDUCTION + OIL_DEDUCTION)}</td>
                  <td className="p-3 text-right font-bold text-amber-600">{money(TAX_SAVED)}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>

        <footer className="text-xs text-gray-500 pt-4 text-center">
          © 2025 True Harvest Wealth Management — Confidential
        </footer>
      </main>
    </div>
  );
}
