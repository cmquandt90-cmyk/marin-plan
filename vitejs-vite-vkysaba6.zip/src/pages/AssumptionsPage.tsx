// src/pages/AssumptionsPage.tsx
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

/** ---------- Types ---------- */
type FormState = {
  // Sale, Income & Tax
  totalSale: number;
  capGainRateSale: number;    // fraction, e.g., 0.299
  ordinaryIncomeRate: number; // fraction, e.g., 0.428
  income2025: number;

  // Tax Benefits
  dafContribution2025: number;
  oilGas2025: number;

  // Allocations (fractions ~ 1.0 total)
  publicEquityAlloc: number;
  privateEquityAlloc: number;
  privateCreditAlloc: number;
  muniAlloc: number;
  quantinnoAlloc: number;
  realEstateAlloc: number;
  metalsAlloc: number;
  startupsAlloc: number;
  cryptoAlloc: number;

  // ROI (fractions)
  publicEquityGrowth: number;
  privateEquityGrowth: number;
  privateCreditCoupon: number;
  muniCoupon: number;
  quantinnoGrowth: number;
  realEstateGrowth: number;
  metalsGrowth: number;
  startupsGrowth: number;
  cryptoGrowth: number;

  // convenience (used by Results)
  daf?: number;
  oilGas?: number;
};

/** ---------- Utils ---------- */
const TH_BLUE = "#0f2742";

function fmtMoney(n: number) {
  const v = Number.isFinite(n) ? n : 0;
  return "$" + Math.round(v).toLocaleString();
}
function fmtPct(p: number) {
  const v = Number.isFinite(p) ? p : 0;
  return (v * 100).toFixed(2) + "%";
}

/** ---------- Page ---------- */
export default function AssumptionsPage() {
  const navigate = useNavigate();

  // Prefilled ONLY: total sale, DAF, Oil & Gas
  const [form, setForm] = useState<FormState>({
    totalSale: 65_000_000,
    capGainRateSale: 0,
    ordinaryIncomeRate: 0,
    income2025: 0,

    dafContribution2025: 6_500_000,
    oilGas2025: 3_000_000,

    // No pre-added allocations
    publicEquityAlloc: 0,
    privateEquityAlloc: 0,
    privateCreditAlloc: 0,
    muniAlloc: 0,
    quantinnoAlloc: 0,
    realEstateAlloc: 0,
    metalsAlloc: 0,
    startupsAlloc: 0,
    cryptoAlloc: 0,

    // No pre-added ROI
    publicEquityGrowth: 0,
    privateEquityGrowth: 0,
    privateCreditCoupon: 0,
    muniCoupon: 0,
    quantinnoGrowth: 0,
    realEstateGrowth: 0,
    metalsGrowth: 0,
    startupsGrowth: 0,
    cryptoGrowth: 0,
  });

  const handleChange = <K extends keyof FormState>(key: K, val: FormState[K]) =>
    setForm((prev) => ({ ...prev, [key]: val }));

  const goToResults = () => {
    const normalized = {
      ...form,
      daf: form.dafContribution2025,
      oilGas: form.oilGas2025,
    };
    navigate("/results", { state: { form: normalized } });
  };

  const allocSum =
    form.publicEquityAlloc +
    form.privateEquityAlloc +
    form.privateCreditAlloc +
    form.muniAlloc +
    form.quantinnoAlloc +
    form.realEstateAlloc +
    form.metalsAlloc +
    form.startupsAlloc +
    form.cryptoAlloc;

  return (
    <div className="min-h-screen bg-gray-100 text-gray-900">
      {/* Header */}
      <header className="flex items-center justify-between px-8 py-6 bg-white border-b sticky top-0 z-10">
        <div className="flex items-center gap-4">
          <img src="/LOGO.png" alt="True Harvest" className="h-14 w-auto" />
          <div>
            <h1 className="text-3xl font-extrabold" style={{ color: TH_BLUE }}>
              Assumptions — Marvin Family
            </h1>
            <p className="text-sm text-gray-600">
              Enter assumptions below, then generate the report.
            </p>
          </div>
        </div>

        <button
          onClick={goToResults}
          className="rounded-xl bg-[rgb(193,137,23)] text-white font-semibold px-4 py-2 shadow hover:opacity-95 active:scale-[0.99] transition"
        >
          See Results
        </button>
      </header>

      <main className="max-w-7xl mx-auto p-8 space-y-10">
        {/* Sale, Income & Tax */}
        <SectionCard title="Sale, Income & Tax">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <MoneyInput
              label="Total Sale"
              value={form.totalSale}
              onChange={(v) => handleChange("totalSale", v)}
            />
            <MoneyInput
              label="2025 Income"
              placeholder="e.g. 12000000"
              value={form.income2025}
              onChange={(v) => handleChange("income2025", v)}
            />
            <PercentInput
              label="Capital Gain Tax Rate (Sale)"
              placeholder="e.g. 29.9"
              value={form.capGainRateSale}
              onChange={(v) => handleChange("capGainRateSale", v)}
            />
            <PercentInput
              label="Ordinary Income Tax Rate"
              placeholder="e.g. 42.8"
              value={form.ordinaryIncomeRate}
              onChange={(v) => handleChange("ordinaryIncomeRate", v)}
            />
          </div>
        </SectionCard>

        {/* Tax Benefits */}
        <SectionCard title="Tax Benefit Assumptions">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <MoneyInput
              label="2025 Donor Advised Fund Contribution"
              value={form.dafContribution2025}
              onChange={(v) => handleChange("dafContribution2025", v)}
            />
            <MoneyInput
              label="2025 Oil & Gas Investment"
              value={form.oilGas2025}
              onChange={(v) => handleChange("oilGas2025", v)}
            />
          </div>
        </SectionCard>

        {/* Allocations */}
        <SectionCard
          title="Allocation Assumptions"
          subtitle={
            <span
              className={`${
                Math.abs(allocSum - 1) < 0.001 ? "text-emerald-700" : "text-amber-700"
              } text-sm`}
            >
              Total: <strong>{fmtPct(allocSum)}</strong>{" "}
              {Math.abs(allocSum - 1) < 0.001 ? "(OK)" : "(should be ~100%)"}
            </span>
          }
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <PercentInput
              label="Public Equity"
              placeholder="e.g. 16.67"
              value={form.publicEquityAlloc}
              onChange={(v) => handleChange("publicEquityAlloc", v)}
            />
            <PercentInput
              label="Private Equity"
              placeholder="e.g. 22.22"
              value={form.privateEquityAlloc}
              onChange={(v) => handleChange("privateEquityAlloc", v)}
            />
            <PercentInput
              label="Private Credit"
              placeholder="e.g. 11.11"
              value={form.privateCreditAlloc}
              onChange={(v) => handleChange("privateCreditAlloc", v)}
            />
            <PercentInput
              label="Municipal Bonds"
              placeholder="e.g. 11.11"
              value={form.muniAlloc}
              onChange={(v) => handleChange("muniAlloc", v)}
            />
            <PercentInput
              label="Quantinno"
              placeholder="e.g. 11.11"
              value={form.quantinnoAlloc}
              onChange={(v) => handleChange("quantinnoAlloc", v)}
            />
            <PercentInput
              label="Real Estate"
              placeholder="e.g. 22.22"
              value={form.realEstateAlloc}
              onChange={(v) => handleChange("realEstateAlloc", v)}
            />
            <PercentInput
              label="Precious Metals"
              placeholder="e.g. 5.55"
              value={form.metalsAlloc}
              onChange={(v) => handleChange("metalsAlloc", v)}
            />
            <PercentInput
              label="Startups / Angel"
              placeholder="e.g. 5.56"
              value={form.startupsAlloc}
              onChange={(v) => handleChange("startupsAlloc", v)}
            />
            <PercentInput
              label="Crypto"
              placeholder="e.g. 5.56"
              value={form.cryptoAlloc}
              onChange={(v) => handleChange("cryptoAlloc", v)}
            />
          </div>

          {/* Footnote */}
          <p className="mt-3 text-xs text-gray-500">
            Allocations apply to investable net proceeds (after taxes), excluding DAF and Oil &amp; Gas elections.
          </p>
        </SectionCard>

        {/* ROI */}
        <SectionCard title="ROI Assumptions">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <PercentInput
              label="Public Equity Growth Rate"
              placeholder="e.g. 10"
              value={form.publicEquityGrowth}
              onChange={(v) => handleChange("publicEquityGrowth", v)}
            />
            <PercentInput
              label="Private Equity Growth Rate"
              placeholder="e.g. 12"
              value={form.privateEquityGrowth}
              onChange={(v) => handleChange("privateEquityGrowth", v)}
            />
            <PercentInput
              label="Private Credit Coupon Rate"
              placeholder="e.g. 8"
              value={form.privateCreditCoupon}
              onChange={(v) => handleChange("privateCreditCoupon", v)}
            />
            <PercentInput
              label="Municipal Bond Coupon Rate"
              placeholder="e.g. 5"
              value={form.muniCoupon}
              onChange={(v) => handleChange("muniCoupon", v)}
            />
            <PercentInput
              label="Quantinno Growth Rate"
              placeholder="e.g. 10"
              value={form.quantinnoGrowth}
              onChange={(v) => handleChange("quantinnoGrowth", v)}
            />
            <PercentInput
              label="Real Estate Growth Rate"
              placeholder="e.g. 8"
              value={form.realEstateGrowth}
              onChange={(v) => handleChange("realEstateGrowth", v)}
            />
            <PercentInput
              label="Precious Metals Growth Rate"
              placeholder="e.g. 6"
              value={form.metalsGrowth}
              onChange={(v) => handleChange("metalsGrowth", v)}
            />
            <PercentInput
              label="Startups / Angel Growth Rate"
              placeholder="e.g. 20"
              value={form.startupsGrowth}
              onChange={(v) => handleChange("startupsGrowth", v)}
            />
            <PercentInput
              label="Crypto Growth Rate"
              placeholder="e.g. 12"
              value={form.cryptoGrowth}
              onChange={(v) => handleChange("cryptoGrowth", v)}
            />
          </div>
        </SectionCard>

        <div className="flex justify-end">
          <button
            onClick={goToResults}
            className="rounded-xl bg-[rgb(193,137,23)] text-white font-semibold px-6 py-3 shadow hover:opacity-95"
          >
            See Results
          </button>
        </div>
      </main>
    </div>
  );
}

/** ---------- Polished building blocks (no external UI libs) ---------- */

function SectionCard({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <section className="bg-white rounded-2xl shadow p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold" style={{ color: TH_BLUE }}>
          {title}
        </h2>
        {subtitle ? <div>{subtitle}</div> : null}
      </div>
      {children}
    </section>
  );
}

function MoneyInput({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  placeholder?: string;
}) {
  const display = fmtMoney(value);
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <input
        type="number"
        value={Number.isFinite(value) ? value : 0}
        onChange={(e) => onChange(e.target.value === "" ? 0 : +e.target.value)}
        placeholder={placeholder}
        className="border rounded-lg p-2 w-full focus:ring-2 focus:ring-indigo-500"
      />
      <p className="text-xs text-gray-500 mt-1">
        Preview: <span className="font-semibold">{display}</span>
      </p>
    </div>
  );
}

/** PercentInput — free typing with fractional storage */
function PercentInput({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: number; // stored as 0.299 for 29.9%
  onChange: (v: number) => void;
  placeholder?: string;
}) {
  const [text, setText] = useState<string>(() =>
    Number.isFinite(value) && value !== 0 ? String(value * 100) : ""
  );
  const [focused, setFocused] = useState(false);

  useEffect(() => {
    if (!focused) {
      setText(Number.isFinite(value) && value !== 0 ? String(value * 100) : "");
    }
  }, [value, focused]);

  const commit = () => {
    const raw = text.replace(/[%\s,]/g, "");
    if (raw === "" || raw === "-" || raw === "." || raw === "-.") {
      onChange(0);
      setText("");
      return;
    }
    const n = Number(raw);
    if (Number.isFinite(n)) {
      onChange(n / 100);
      setText(String(n));
    } else {
      setText(Number.isFinite(value) && value !== 0 ? String(value * 100) : "");
    }
  };

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <div className="flex items-center gap-2">
        <input
          type="text"
          inputMode="decimal"
          placeholder={placeholder ?? "0.00"}
          value={text}
          onChange={(e) => setText(e.target.value)}
          onBlur={commit}
          onFocus={() => setFocused(true)}
          onKeyDown={(e) => {
            if (e.key === "Enter") (e.target as HTMLInputElement).blur();
          }}
          className="border rounded-lg p-2 w-full text-right focus:ring-2 focus:ring-indigo-500"
        />
        <span className="text-sm text-gray-500">%</span>
      </div>
      <p className="text-xs text-gray-500 mt-1">
        Preview: <span className="font-semibold">{fmtPct(value)}</span>
      </p>
    </div>
  );
}
